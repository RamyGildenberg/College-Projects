import "./NetworkGraph.css";

function NetworkGraph() {
  return (
    <div className="network-graph">
      <iframe title="test" src="http://localhost:5005/"></iframe>
    </div>
  );
}

export default NetworkGraph;
