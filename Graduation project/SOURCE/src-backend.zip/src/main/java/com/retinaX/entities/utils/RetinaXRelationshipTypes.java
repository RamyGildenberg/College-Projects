package com.retinaX.entities.utils;



public class RetinaXRelationshipTypes {
    public static final String
            FUNCTION_INPUT_VARIABLE = "FUNCTION_INPUT_VARIABLE",
            FROM_CELL = "FROM_CELL",
            TO_CELL = "TO_CELL",
            FROM_TYPE = "FROM_TYPE",
            CELL_TYPE_FUNCTION = "CELL_TYPE_FUNCTION",
            FUNCTION_VARS = "FUNCTIONS_VARS",
            FROM_GRAPH = "FROM_GRAPH";


}