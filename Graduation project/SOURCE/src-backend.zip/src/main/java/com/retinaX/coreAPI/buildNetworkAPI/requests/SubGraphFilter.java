package com.retinaX.coreAPI.buildNetworkAPI.requests;

public class SubGraphFilter {

    String name;

    public SubGraphFilter(String name) {
        this.name = name;
    }
    public SubGraphFilter() {

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
