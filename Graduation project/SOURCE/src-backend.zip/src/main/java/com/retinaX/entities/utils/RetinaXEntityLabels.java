package com.retinaX.entities.utils;


public class RetinaXEntityLabels {
    public static final String CELL_INSTANCE = "CellInstance",
    CELL_TYPE = "CellType",
    CONNECTION = "Connection",
    FUNCTION = "Function",
    VARIABLE =  "Variable",
    SUB_GRAPH_INSTANCE = "SubGraphInstance";


}






