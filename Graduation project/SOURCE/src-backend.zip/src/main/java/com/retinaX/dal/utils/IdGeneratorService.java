package com.retinaX.dal.utils;

public interface IdGeneratorService {
    Long nextId();
}
