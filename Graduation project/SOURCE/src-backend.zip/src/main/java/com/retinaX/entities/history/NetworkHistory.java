package com.retinaX.entities.history;

public class NetworkHistory {

    private String sessionID;
    private String networkID;
}
