package com.retinaX.entities.history;

public class CellHistory {

    private String cellID;
    private String sessionID;
}
