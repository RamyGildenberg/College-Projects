/*
 * city.h
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */

#ifndef CITY_H_
#define CITY_H_

#include "kindergarten.h"

#define FILE_NAME "DataFile.txt"

typedef struct {
	Kindergarten** kindergartens;
	int numberOfKindergartens;
}City;
int searchForKindergarten(City *city,char* name);
void readCity(City* city);

#endif /* CITY_H_ */
