/*
 * child.h
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */

#ifndef CHILD_H_
#define CHILD_H_
#include <stdio.h>

typedef struct
{
	int id;
	int age;
}Child;

void printChildInfo(Child* child);
void writeChildToFile(FILE *file,Child* child);
void getChildFromFile(FILE *file,Child* child);


#endif /* CHILD_H_ */
