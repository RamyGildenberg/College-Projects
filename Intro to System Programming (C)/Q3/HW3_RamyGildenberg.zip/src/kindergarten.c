/*
 * kindergarten.c
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "kindergarten.h"
#include "miscFunctions.h"
const char* Gartentypes[]={"Chova","Trom Chova","Trom Trom Chova"};

void printKindergarten(Kindergarten* kindergarten)
{
	int i;
	printf("Name:%s\tType:%d Number of children:%d\n",kindergarten->name,kindergarten->type,
			kindergarten->numOfChildren);
	for(i=0;i< kindergarten->numOfChildren;i++)
		printChildInfo(kindergarten->children[i]);

}
void readKindergarten(FILE *file,Kindergarten* kindergarten)
{
	if(file !=NULL)
	{
		int k,i;
		kindergarten->name=getGardenName(file);
		fscanf(file,"%d %d",&(kindergarten->type),&(kindergarten->numOfChildren));
		kindergarten->children=(Child**)malloc(sizeof(Child*)*kindergarten->numOfChildren);
		if(!checkMemAlloc(kindergarten->children))
			return;
		for(k=0;k<kindergarten->numOfChildren;i++)
		{
			kindergarten->children[k]=(Child*)malloc(sizeof(Child));
			if(checkMemAlloc(!kindergarten->children[k]))
				return;
		}
		for(i=0;i<kindergarten->numOfChildren;i++)
		{
			getChildFromFile(file,kindergarten->children[i]);
		}
		getc(file);

	}
}
char* getGardenName(FILE *file)
{
	char* gardenName;
	char temp[100];
	fscanf(file,"%s",temp);
	gardenName=strdup(temp);
	return gardenName;
}
void wrtieKindgartenToFile(FILE *file,Kindergarten* kindergarten)
{
	int i;
	fprintf(file,"%s %d %d\n",kindergarten->name,kindergarten->type,kindergarten->numOfChildren);
	for(i=0;i<kindergarten->numOfChildren;i++)
		writeChildToFile(file,kindergarten->children[i]);
}

