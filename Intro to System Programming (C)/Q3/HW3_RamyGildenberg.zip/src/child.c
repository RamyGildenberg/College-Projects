/*
 * child.c
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */
#include "child.h"
#include "miscFunctions.h"

void printChildInfo(Child* child)
{
	printf("Age:%d\tID:%d.\n",child->age,child->id);
}
void writeChildToFile(FILE *file,Child* child)
{
	fprintf(file,"%d %d\n",child->id,child->age);
}

void getChildFromFile(FILE *file,Child* child)
{
	fscanf(file,"%d %d\n",&(child->id),&(child->age));
}
