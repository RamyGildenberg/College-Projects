/*
 * miscFunctions.h
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */
#include <stdlib.h>
#ifndef MISCFUNCTIONS_H_
#define MISCFUNCTIONS_H_
#define READ_CITY 1
#define SHOW_CITY 2
#define SHOW_GARDEN 3
#define WRITE_CITY 4
#define ADD_GARDEN 5
#define ADD_CHILD 6
#define CHILD_BIRTHDAY 7
#define COUNT_GRADUATE 8
#define EXIT 0

int menu();
void printMenu();
int checkMemAlloc(void *p);




#endif /* MISCFUNCTIONS_H_ */
