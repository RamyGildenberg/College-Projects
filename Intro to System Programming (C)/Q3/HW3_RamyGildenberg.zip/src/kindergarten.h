/*
 * kindergarten.h
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */

#ifndef KINDERGARTEN_H_
#define KINDERGARTEN_H_
#include "child.h"

const char* Gartentypes[3];

typedef struct
{
	char* name;
	int type;
	int numOfChildren;
	Child** children;
}Kindergarten;
void readKindergarten(FILE *file,Kindergarten* kindergarten);
char* getGardenName(FILE *file);
void wrtieKindgartenToFile(FILE *file,Kindergarten* kindergarten);
void printKindergarten(Kindergarten* kindergarten);

#endif /* KINDERGARTEN_H_ */
