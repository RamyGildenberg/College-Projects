/*
 * miscFunctions.c
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */

#include <stdio.h>
#include "miscFunctions.h"

int checkMemAlloc(void *p)
{
	if(p==NULL)
		return 0;
	return 1;
}
int menu()
{
	int choice;
	printf("\n==========================\n"
					"1. Read City information.\n"
					"2. Show all Kindergartens.\n"
					"3. Show a specified Kindergarten.\n"
					"4. Save City information.\n"
					"5. Add a Kindergarten.\n"
					"6. Add a Child.\n"
					"7. Add to child's birth year.\n"
					"8. Show number of children in Hova.\n"
					"0. Exit.\n");
	scanf("%d", &choice);
	getchar();
	return choice;
}



