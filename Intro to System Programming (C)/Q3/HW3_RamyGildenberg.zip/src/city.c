/*
 * city.c
 *
 *  Created on: 25 Dec 2018
 *      Author: Ramy Gildenberg
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "city.h"
#include "kindergarten.h"
/*read from file*/
void readCity(City* city)
{
	int result;
	int i;
	FILE *file;
	file=fopen("DataFile.txt","r");
	if(file != NULL)
	{
		fscanf(file,"%d",&(city->numberOfKindergartens));
		/* Allocate memory for the Kindergarten array */
		city->kindergartens=(Kindergarten**) malloc(city->numberOfKindergartens*sizeof(Kindergarten*));
		if(!checkMemAlloc(city->kindergartens))
			return;
		for(i=0;i< city->numberOfKindergartens ;i++)
		{

			/* Allocate memory for each kindergarten in the kindergarten array*/
			city->kindergartens[i] = (Kindergarten*) malloc(sizeof(Kindergarten));
			if(!checkMemAlloc(!city->kindergartens[i]))
				return;

		}
		for(i=0; i<city->numberOfKindergartens;i++)
		{
			readKindergarten(file,city->kindergartens[i]);
		}

	}
	fclose(file);

}
void showCityGardens(const City* city)
{
	int i,k;
	for(i=0;i<city->numberOfKindergartens;i++){
		printf("Kindergarten %d:\n",i+1);
		printf("Name:%s\tType:%s\tChildren:%d\n",city->kindergartens[i]->name,Gartentypes[city->kindergartens[i]->type],city->kindergartens[i]->numOfChildren);
		for(k=0;i<city->kindergartens[i]->numOfChildren;i++)
		{
			printChildInfo(city->kindergartens[i]->children[k]);
		}
	}

}
void showSpecificGardenInCity(City* city)
{
	char* str1;
	char str2[100];
	printf("Give me the Kindergarten Name:\n");
	scanf("%s",str2);
	getchar();
	str1=strdup(str2);
	if(searchForKindergarten(city,str1)!= -1)
	{
		printKindergarten(city->kindergartens[searchForKindergarten(city,str1)]);
	}

}
int searchForKindergarten(City *city,char* name)// will search for the kindergarten and return its index, if its not found return -1 , otherwise return the index
{
	int i;

	for(i=0;i<city->numberOfKindergartens;i++)
	{
		if(!strcmp(name,city->kindergartens[i]->name))
		{
			return i;
		}
		else
			if(i==city->numberOfKindergartens-1)
				printf("No Such Kindergarten");
	}
	return -1;

}
int countChova(City* city)
{
	int counter,i;
	for(i=0;i<city->numberOfKindergartens;i++)
		if(city->kindergartens[i]->type==0)
			counter+=city->kindergartens[i]->numOfChildren;
	return counter;
}
void saveCity(City* city)
{
	int i;
	FILE *file;
	file=fopen("DataFile.txt","w");
	if(file !=NULL)
	{
		fprintf(file,"%d\n",city->numberOfKindergartens);
		for(i=0;i<city->numberOfKindergartens;i++)
		{
			wrtieKindgartenToFile(file,city->kindergartens[i]);
		}
	}
	fclose(file);
}
void ReleaseCity(City* city)
{
	int i,k;
	for(i=0;i<city->numberOfKindergartens;i++)
	{
		for(k=0;k<city->kindergartens[i]->numOfChildren;k++)
			free(city->kindergartens[i]->children[i]);
		free(city->kindergartens[i]->name);
		free(city->kindergartens[i]->children);
	}
	free(city->kindergartens);
}
void birthdayToChild(City* city)
{
	int idSearch,i;
	char str1[100];
	printf("Give The Name Of The Kindergarten:\n");
	scanf("%s",str1);
	getchar();
	if(searchForKindergarten(city,str1)!= -1)
	{
		printf("Enter Child's ID:\n");
		scanf("%d",&idSearch);
		for(i=0;i<city->kindergartens[searchForKindergarten(city,str1)]->numOfChildren;i++)
		{
			if(city->kindergartens[searchForKindergarten(city,str1)]->children[i]->id == idSearch)
				(city->kindergartens[searchForKindergarten(city,str1)]->children[i]->age)++;
			else
				if(i+1==city->kindergartens[searchForKindergarten(city,str1)]->numOfChildren)//if we reached the end of the kindergarten's array and the child
																							 //wasn't found,we print out an error.
					printf("Child Is Not Found");
		}
	}
}
void addChildToSpecificGardenInCity(City* city)
{

}
void cityAddGarden(City* city)
{

}








