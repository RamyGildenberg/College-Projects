/*
 ============================================================================
 Name        : HW2.c
 Author      : Ramy Gildenberg
 Version     :
 Copyright   : 
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>


#define  NEW_STRING 		1
#define  CURRENT_STRING 	2
#define  COUNT_WORDS 	3
#define  LONGEST_WORD 	4
#define  REVERT_WORD 	5
#define  CHECK_ERASE_CHARS 6
#define  CHECK_PALINDROME 	7
#define  EXIT 			-1
#define  MAX_LEN	      100
#define DELIMITER_NUM 5
char delimiters[]=" ,:?-";

int main()
  {
	int option;
	char str[MAX_LEN] = "\0";

	do {
		printMenu();
		scanf("%d",&option);
		performChoice(option, str);

	} while(option != EXIT);

	return EXIT_SUCCESS;
  }


void printMenu() {
	printf("\n\n");
	printf("Please choose one of the following options\n");
	printf("%d - Enter new string\n", NEW_STRING);
	printf("%d - Print current string\n", CURRENT_STRING);
	printf("%d - Count words in string\n", COUNT_WORDS);
	printf("%d - Print longest word in string CAPITALIZED\n", LONGEST_WORD);
	printf("%d - Revert each word in string\n", REVERT_WORD);
	printf("%d - Check eraseCharsFromStr\n", CHECK_ERASE_CHARS);
	printf("%d - Check palindrome\n", CHECK_PALINDROME);
	printf("%d - Exit\n", EXIT);
}


void performChoice(int option, char* str) {

	switch (option)
	{
	case NEW_STRING:
		initString(str, MAX_LEN);
		break;

	case CURRENT_STRING:
		printString(str);
		break;

	case COUNT_WORDS:
	{
		int count = countWords(str);
		printf("There are %d words in string\n", count);
		break;
	}
	case LONGEST_WORD:
		longestInCaptital(str);
		printf("String after longest capital %s\n", str);
		break;

	case REVERT_WORD:
		revertWords(str);
		printf("String after revert %s\n", str);
		break;

	case CHECK_ERASE_CHARS:
		eraseCharsFromString(str, ":, ?!-;");
		printf("String after erase %s\n", str);
		break;

	case CHECK_PALINDROME:
		if (isPalindrome(str))
			printf("String %s is palindrome\n", str);
		else
			printf("String %s is NOT palindrome\n", str);
		break;


	case EXIT:
		printf("Bye bye\n");
		break;

	default:
		printf("Wrong option\n");
		break;
	}

}


//Q1
void initString(char* str,int maxLen)
{
	printf("Please enter a string");
  	fgets(str,maxLen,stdin);
  	if(str[strlen(str)-1]=='\n')
  		str[strlen(str)-1]='\0';

}

//Q2
void printString(char* str)
{
  	printf("\nThe String:\n%s",str);
}

  //Q3
int countWords(char* str)
{
  	char copyString[strlen(str)],*token;
  	int counter=0;
  	strcpy(copyString,str);
  	/* get the first token */
  	token=strtok(copyString,delimiters);
  	/* walk through other tokens */
  	while(token!=NULL)
  	{
  		counter++;
  		token = strtok(NULL,delimiters);
  	}
  	return counter;
}

  //Q4
void longestInCaptital(char* str)
{

  	char copyString[strlen(str)],*token,longestWord[strlen(str)];
  	int length,biggestLen=0;
  	strcpy(copyString,str);
  	token=strtok(copyString,delimiters);

  	while(token != NULL)
  	{

  		length=strlen(token);

  		if(length>biggestLen)
  		{
  			biggestLen=length;
  			strcpy(longestWord,token);
  		}
  		token=strtok(NULL,delimiters);
  	}

  	str=strstr(str,longestWord);
  	int charCount=strlen(longestWord);
  	for(int i=0;i<charCount-1;i++)
  	{
  		*str=toupper(*str);
  		str++;
  	}
}

  //Q5
void revertWords(char* str)
{

  	char newDelimiter[]= "*" ;
  	/* run over the string and change of the delimiters to '*' */
  	for(int i=0;i<strlen(str);i++)
  	{
  		for(int j=0;j<DELIMITER_NUM;j++)
  		{
  			if(delimiters[j]==str[i])
  				str[i]=newDelimiter;
  		}
  	}

  	char copyString[strlen(str)],*token;
  	strcpy(copyString,str);
  	/* get the first token */
  	token=strtok(copyString,newDelimiter);

  	while(token)
  	{

  		/* while there is a delimiter , keep running over the string */
  		while(*str==*newDelimiter)
  		{
  			str+=1;
  		}

  		/* when we get to the first word , we start from the end of the word, and change the first
  		 letter to the last letter */
  		for(int i=strlen(token)-1;i>=0;i--)
  		{
  			*str=token[i];
  			str++;
  		}
  		token=strtok(NULL,newDelimiter);
  	}

}

//Q6
void eraseCharsFromString (char *str, const char *symbols)
{
	char copyString[strlen(str)],*token,newStr[strlen(str)];
	strcpy(copyString,str);
	/* break the string , where the selected symbold are the delimiters*/
	token=strtok(copyString,symbols);
	while(token !=NULL)
	{
		/*append to the new string , the pieces of the old string , but without the selected symbols */
		strcat(newStr,token);
		token=strtok(NULL,symbols);
	}
	strcpy(str,newStr);
}

//Q7

int isPalindrome(const char *str)
{
	char *startPointer,*endPointer;
	*startPointer=str;
	*endPointer=*startPointer+strlen(str)-1;
	/* while the pointer is not on a alphabetical letter, move it to an alphabetical letter*/
	while(checkAlphabeical(startPointer)!=1)
	{
		startPointer++;
	}
	/* while the pointer is not on a alphabetical letter, move it to an alphabetical letter*/
	while(checkAlphabeical(endPointer)!=1)
	{
		endPointer--;
	}
	for(int i=0;i<=strlen(str)/2;i++)
	{
		/* move the pointer if it is not an alphabetical letter and reduce the i counter to compensate*/
		if(checkAlphabeical(endPointer)!=1){
			endPointer--;
			i--;}
		/* move the pointer if it is not an alphabetical letter and reduce the i counter to compensate*/
		if(checkAlphabeical(startPointer)!=1){
			startPointer++;
			i--;}
		if((endPointer!=startPointer) && checkAlphabeical(startPointer)==1 && checkAlphabeical(endPointer)==1)
			return 1;
	}
	return 0;
}
int checkAlphabeical(char* pointer)
{
	if( (pointer>='a' && pointer<='z') || (pointer>='A' && pointer<='Z'))
	        return 1;
	    else
	        return 0;

}


