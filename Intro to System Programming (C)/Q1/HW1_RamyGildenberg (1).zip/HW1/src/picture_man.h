/*
 * picture_man.h
 *
 *  Created on: 21 Nov 2018
 *      Author: Ramy Gildenberg
 */

#ifndef PICTURE_MAN_H_
#define PICTURE_MAN_H_

typedef enum {False,True} boolean;



void pictureManipulation(int* mat,int size);
void printMat(int* mat,int row,int col);
void chnageClockwise(int*mat,int row,int col,int direction);
void flipChange(int* mat,int row,int col,int direction);
void swap(int* p1,int* p2);


#endif /* PICTURE_MAN_H_ */
