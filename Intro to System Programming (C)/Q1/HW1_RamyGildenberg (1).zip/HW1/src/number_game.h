/*
 * number_game.h
 *
 *  Created on: 21 Nov 2018
 *      Author: Ramy Gildenberg
 */

#ifndef NUMBER_GAME_H_
#define NUMBER_GAME_H_
typedef enum {FALSE,TRUE} boolean;

void numberGame(int* mat,int Size);


#endif /* NUMBER_GAME_H_ */
