/*
 * number_game.c
 *
 *  Created on: 21 Nov 2018
 *      Author: Ramy Gildenberg
 */
#include <stdio.h>
#include "number_game.h"
void numberGame(int* mat,int Size)
{
		printf("\nPlease choose one of the following options:\n");
		printf("\n1-90 degree clockwise");
		printf("\n2-90 degree counter clockwise");
		printf("\n3-Flip Horizontal");
		printf("\n4-Flip Vertical");
		printf("\n-1-Quit\n");
}

