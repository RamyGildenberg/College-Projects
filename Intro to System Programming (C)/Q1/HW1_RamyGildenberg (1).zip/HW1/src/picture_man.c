/*
 * picture_man.c
 *
 *  Created on: 21 Nov 2018
 *      Author: Ramy Gildenberg
 */
#include <stdio.h>
#include "picture_man.h"


void pictureManipulation(int* mat,int size)
{
	boolean picManMenu;
	picManMenu=True;
	prodMat(mat,size,size,True);
	printMat(mat,size,size);
	while(picManMenu)
	{
		printf("\nPlease choose one of the following options:\n");
		printf("\n1-90 degree clockwise");
		printf("\n2-90 degree counter clockwise");
		printf("\n3-Flip Horizontal");
		printf("\n4-Flip Vertical");
		printf("\n-1-Quit\n");
		int choise;
		scanf("%d",&choise);
		getchar();
		switch(choise)
		{
			case 1:
			{
				printf("\n--------------Picture after manipulation--------------\n");
				chnageClockwise(mat,size,size,1);
				printMat(mat,size,size);
				break;
			}
			case 2:
			{
				printf("\n--------------Picture after manipulation--------------\n");
				chnageClockwise(mat,size,size,0);
				printMat(mat,size,size);
				break;
			}
			case 3:
			{
				printf("\n--------------Picture after manipulation--------------\n");
				flipChange(mat,size,size,1);
				printMat(mat,size,size);
				break;
			}
			case 4:
			{
				printf("\n--------------Picture after manipulation--------------\n");
				flipChange(mat,size,size,2);
				printMat(mat,size,size);
				break;
			}
			case -1:
			{
				picManMenu=False;
				break;
			}

		}
	}
}
void chnageClockwise(int* mat,int row,int col,int direction)
{


	if(direction==0)
	{
		printf("\nTurn Counter Clockwise\n");
		transposeMat(mat,row,col);
		flipChange(mat,row,col,1);
	}
	if(direction==1)
	{
		printf("\nTurn Clockwise\n");
		flipChange(mat,row,col,1);
		transposeMat(mat,row,col);
	}
}



void flipChange(int* mat,int row,int col,int direction)
{

	if(direction==1) // Horizontal Flip
	{

		for(int i=0;i<row/2;i++)
			for(int j=0;j<col;j++)
			{

				swap(&(*(mat+(i*row)+j)),&(*(mat+((row-1-i)*row)+j)));
			}

	}
	if(direction==2) //Vertical Flip
	{

			for(int i=0;i<row;i++)
			{
				for(int j=0;j<col/2;j++)
				{

				swap(&(*(mat+(i*row)+j)),&(*(mat+(i*row)+col-1-j)));
				}

		}

	}


}
void printMat(int* mat,int row,int col)
{
	for(int i=0;i<=row-1;i++)
	{
		for(int j=0;j<=col-1;j++)
		{
			printf("%4d",*(mat+(i*row)+j));
		}
		printf("\n");
	}
}
void transposeMat(int* mat,int row,int col)
{
	printf("\ntransposeMat entered\n");
	for(int i=0;i<row;i++)
		for(int j=i;j<col;j++)
			swap(&(*(mat+(i*row)+j)),&(*(mat+(j*col)+i)));
}
void swap(int* p1,int* p2)
{
	int temp;
	temp=*p1;
	*p1=*p2;
	*p2=temp;
}




