/*
 ============================================================================
 Name        : HW1.c
 Author      : Ramy Gildenberg
 ============================================================================
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include "picture_man.h"
#define MAX_SIZE_MAT 4
#define MIN_SIZE_MAT 2
#define MAX_RANDOM_VALUE 50
#define MIN_RANDOM_VALUE 1
int main(void) {

	boolean menuChoiseFlag=True;
	srand(time(NULL));
	int randomSize=(rand() % (MAX_SIZE_MAT-MIN_SIZE_MAT)+1)+MIN_SIZE_MAT; //get a random matrix size between 3 and 7
	int mat[randomSize][randomSize];
	while(menuChoiseFlag)
	{
		printf("Please choose one of the following options:\n");
		printf("\nP/p - Picture Manipulation");
		printf("\nN/n - Number Game");
		printf("\nE/e - Quit\n");
		char choise;
		scanf("%c",&choise);
		getchar();
		switch(toupper(choise))
		{
			case 'P':
				prodMat(mat,randomSize,randomSize,True);
				pictureManipulation(mat,randomSize);
				break;
			case 'N':
				prodMat(mat,randomSize,randomSize,False);
				numberGame(mat,randomSize);
				break;
			case 'E':
			{
				printf("Good Bye\n");
				menuChoiseFlag=False;
				break;
			}
		}

	}

}
void prodMat(int* mat,int rows,int cols,boolean random)
{
	if(random)
		for(int i=0;i<rows*cols;i++)
		{
			*(mat+i)=(rand() % (MAX_RANDOM_VALUE-MIN_RANDOM_VALUE)+1)+MIN_RANDOM_VALUE;
		}
	else
		{
		for(int i=0;i<rows*cols;i++)
			*(mat+i)=i;
		}
}
