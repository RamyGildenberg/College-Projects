#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Child.h"
#include "General.h"


/**************************************************/
/*             Read a Child from a file           */
/**************************************************/
void readChild(FILE* fp, Child* pChild)
{
	//Child ID
	fscanf(fp, "%d", &pChild->id);
	fscanf(fp, "%d", &pChild->age);
}


/**************************************************/
/*            show a Child				           */
/**************************************************/
void showChild(const Child* pChild)
{
	printf("\nID:%d  ", pChild->id);
	printf("Age:%d  ", pChild->age);
}


/**************************************************/
void getChildFromUser(Child* pChild, int id)
/**************************************************/
/**************************************************/
{
	pChild->id = id;
	
	puts("\nAge:\t");
	scanf("%d", &pChild->age);
}


/**************************************************/
/*Write a Child to the open file				*/
/**************************************************/
void writeChild(FILE* fp,const Child* pChild)
{
	fprintf(fp,"%d %d\n",pChild->id, pChild->age);
}

//linear search
int	findChildById(Child** pChildList, int count, int id)
{
	//sort the array
	qsort(pChildList,count,sizeof(Child*),compareChildID);
	//make a mock child with the id we want to look, since the search is comparing objects we can't just compare the id , we need to make a new child object
	//with the ID we want to look for , and enter that object to the bsearch
	Child keyChild={id,0};
	Child** foundEntery;//an object that will point to the pointer of the found entery
	foundEntery=bsearch(&keyChild,pChildList,count,sizeof(Child*),compareChildID);
	if(foundEntery==NULL)
		return -1;
	else
		return foundEntery-pChildList;//since we will get a pointer to the entery and it has an address , we will reduce the address of array from the entery
									  //and get the exact index of the looked for child

}

void birthday(Child* pChild)
{
	pChild->age++;
}



void	releaseChild(Child* pChild)
{
	//nothing to release
}
int compareChildID(const void* child1,const void* child2)
{
	Child* x1=*(Child**) child1;
	Child* x2=*(Child**) child2;
	return (x1->id-x2->id);
}
