#include <stdio.h>
#include <stdlib.h>

#include "General.h"
#include "Kindergarten.h"
#include "Child.h"
#include "City.h"




int main(int argc, char* argv[])
{
	int fileType;
	scanf(argv[1],"%d",&fileType);
	if(fileType==0){
		printf("The selected file type is a text file");
	}
	else{
		if(fileType==1)
			printf("the selected file type is a binary file");
	}
	City utz = { NULL,0 };
	int uReq;

	//first time read
	readCity(&utz,fileType);
	do
	{
		uReq = menu();
		switch (uReq)
		{
		case  READ_CITY:
			readCity(&utz,fileType);
			break;

		case  SHOW_CITY:
			showCityGardens(&utz);
			break;

		case  SHOW_GARDEN:
			showSpecificGardenInCity(&utz);
			break;

		case  WRITE_CITY:
			saveCity(&utz,fileType);
			break;

		case  ADD_GARDEN:
			cityAddGarden(&utz);
			break;

		case  ADD_CHILD:
			addChildToSpecificGardenInCity(&utz);
			break;

		case  CHILD_BIRTHDAY:
			birthdayToChild(&utz);
			break;

		case COUNT_GRADUATE:
			printf("There are %d children going to school next year\n",countChova(&utz));
			break;

		case SORT_GARDEN_BY_NAME:
			sortKindergartenByName(&utz);
			break;

		case SORT_GARDEN_BY_CHILD_ID:
			sortKindergartenByChildID(&utz);
			break;

		case SORT_GARDEN_BY_TYPE_AND_NUM_OF_CHILDREN:
			sortKindergartenByTypeAndNumOfChildren(&utz);
			break;

		}
	}while (uReq!=EXIT);
	
	ReleaseCity(&utz);//free all allocations
	
	return EXIT_SUCCESS;
}

