#ifndef __CITY__
#define __CITY__

#include "Kindergarten.h"

#define TEXT_DATA_FILE "DataFile.txt"
#define BINARY_DATA_FILE "DataFile.bin"

typedef struct
{
	Garden** pGardenList;
	int count;
}City;


void	readCity(City* pCity,int fileType);
void	showCityGardens(City* pCity);
void	showSpecificGardenInCity(City* pCity);
void	saveCity(City* pCity,int fileType);
void	cityAddGarden(City* pCity);
void	addChildToSpecificGardenInCity(City* pCity);
void	birthdayToChild(City* pCity);
int		countChova(City* pCity);
void	ReleaseCity(City* pCity);
void sortKindergartenByChildID(City* pCity);
void sortKindergartenByName(City* pCity);

#endif
