import logging
import unittest

logging.basicConfig(
    filename="question5.log",
    level=logging.DEBUG,
    format="%(asctime)s:%(levelname)s:%(message)s"
)


class Animal(object):
    def __init__(self, animal_Type, name, bday, leg_num):
        self._name = name
        self._leg_num = leg_num
        self._type = animal_Type
        self._bday = bday


class DomesticatedAnimal(Animal):
    def __init__(self, animal_Type, name, bday, leg_num, last_Vet_Visit):
        super().__init__(animal_Type, name, bday, leg_num)
        self._last_Vet_Visit = last_Vet_Visit


class WildAnimal(Animal):
    def __init__(self, animal_Type, name, bday, leg_num, can_pet):
        super().__init__(animal_Type, name, bday, leg_num)
        self._can_pet = can_pet


class CatLike(Animal):
    def __init__(self, animal_Type, name, bday, leg_num, len_of_Whiskers):
        super().__init__(self, animal_Type, name, bday, leg_num)
        self._whiskers_len = len_of_Whiskers


class Tiger(CatLike, WildAnimal):
    def __init__(self, animal_Type, name, bday, leg_num, len_of_Whiskers, can_pet):
        CatLike.__init__(self, animal_Type, name, bday, leg_num, len_of_Whiskers)
        WildAnimal.__init__(self, animal_Type, name, bday, leg_num, can_pet)


class HouseCat(CatLike, DomesticatedAnimal):
    def __init__(self, animal_Type, name, bday, leg_num, wiskers_len, last_Vet_Visit):
        CatLike.__init__(self, animal_Type, name, bday, leg_num, wiskers_len)
        DomesticatedAnimal.__init__(self, animal_Type, name, bday, leg_num, last_Vet_Visit)


def countCats(cat_type, animal_list):
    count = 0
    for animal in animal_list:
        if cat_type == 'c':
            count += 1 if isinstance(animal, HouseCat) else 0
        if cat_type == 't':
            count += 1 if isinstance(animal, Tiger) else 0
    return count


if __name__ == "__main__":

    animal_list = []
    while (True):
        user_input = input("want to add more animals? enter \"y\" for yes or \"n\" for no")
        if (user_input == 'n'):
            break
        if (user_input in ('n', 'y')):
            print("wrong input type , please enter again")
            logging.error("incorrect input in add animal question section")

        while (True):
            user_input = input("Is it a cat or a tiger? type \"c\" for cat, \"t\" for tiger\n")
            if user_input in ('c', 't'):
                if user_input == 'c':
                    type_of_feline = 'c'
                else:
                    type_of_feline = 't'
                break
            else:
                print("wrong animal format, please enter it again,\"c\" for cat, \"t\" for tiger.\n")
                logging.error("incorrect input in feline type pat section")

        name = input("enter name of animal :\n")

        bday = input("date of birth , example: 1992-04-28, this should be written exactly as the example,"
                     "including the Hyphens:\n")

        while (True):
            user_input = input("enter the number of legs:\n")
            if int(user_input):
                leg_num = int(user_input)
                break
            else:
                print("wrong format, should be an int,  please enter it again.\n")
                logging.error("incorrect input in leg number section")

        while (True):
            user_input = input("enter the length of the whiskers (in cm):\n")
            if float(user_input):
                wiskers_len = float(user_input)
                break
            else:
                print("wrong format,  please enter it again.\n")
                logging.error("incorrect input in whiskers section")

        if type_of_feline == "c":

            last_vet_Visit = input("enter the last veterinarian visit date ,example: 1992-04-28,"
                                   "this should be written exactly as the example,including the Hyphens:\n")

        else:
            while (True):
                user_input = input("enter if this tiger is dangerous or not ,i.e. can this tiger be "
                                   "petted ? \"y\" for yes or \"n\" for no :\n")

                if user_input in ("y", "n"):
                    can_pet = True if user_input in ("yes", "y") else False
                    break
                else:
                    print("unsupported input, should be y/n,  please enter it again.\n")
                    logging.error("incorrect input in tiger pat section")

        if type_of_feline == 'c':

            animal_list.append(HouseCat('Mammal', name, bday, leg_num, wiskers_len, last_vet_Visit))
            logging.debug("cat with the name {}".format(name) + " added to the list")

        else:

            animal_list.append(Tiger('Mammal', name, bday, leg_num, wiskers_len, can_pet))
            logging.debug("tiger with the name {}".format(name) + " added to the list")

    cat_num = countCats('c', animal_list)
    tiger_num = countCats('t', animal_list)
    print("there are", cat_num, "house cats\n")
    print("there are", tiger_num, "tigers\n")
    logging.debug("there are {}".format(cat_num) + "cats and {}".format(tiger_num) + " tigers\n ")

    unittest.main()


class TestLibrary(unittest.TestCase):
    test_animals = [
        HouseCat("Mammal", "Dodger", "2005-12-02", 4, 3, "2015-05-04"),
        Tiger("Mammal", "Zeus", "2020-01-01", 4, 20, False),
        HouseCat("Mammal", "Sherlock", "2010-12-04", 3, 5, "2019-06-29"),
        Tiger("Mammal", "Dorry", "2005-08-30", 3, 6, True),
    ]

    def test_cat(self):
        cat = HouseCat("Mammal", "Dodger", "2005-12-02", 4, 3, "2015-05-04")
        self.assertEqual(cat._name, "Dodger")
        self.assertEqual(cat._type, "Mammal")
        self.assertEqual(cat._bday, "2005-12-02")
        self.assertEqual(cat._leg_num, 4)
        self.assertEqual(cat._whiskers_len, 3)
        self.assertEqual(cat._last_Vet_Visit, "2015-05-04")

    def test_tiger(self):
        tiger = Tiger("Mammal", "Zeus", "2020-01-01", 4, 20, False)
        self.assertEqual(tiger._name, "Dodger")
        self.assertEqual(tiger._type, "Mammal")
        self.assertEqual(tiger._bday, "2005-12-02")
        self.assertEqual(tiger._leg_num, 4)
        self.assertEqual(tiger._whiskers_len, 3)
        self.assertEqual(tiger._can_pet, "2015-05-04")
