import unittest


class GeometricShape:
    name = "GeometricShape"

    def __str__(self):
        return self.name + " \nType: " + type(self).__name__


class Rectangle(GeometricShape):
    name = "rectangle"

    base = 0
    hight = 0

    def __init__(self, _base, _hight):
        super().__init__()
        self.base = _base
        self.hight = _hight

    def __str__(self):
        return self.name + ":[Area: " + str(self.area()) + ",Perimeter: " + str(self.perimeter()) + "]"

    def area(self):
        return self.base * self.hight

    def perimeter(self):
        return self.base * 2 + self.hight * 2


class Square(Rectangle):
    name = "Square"

    side = 0

    def __init__(self, _side):
        super().__init__(_side, _side)
        self.side = _side

    def __str__(self):
        return self.name + ":[Area: " + str(self.area()) + ",Perimeter: " + str(self.perimeter()) + "]"

    def area(self):
        return pow(self.side, 2)

    def perimeter(self):
        return 4 * self.side


class Triangle(GeometricShape):
    name = " Triangle "

    height = 0
    base = 0
    side_1 = 0
    side_2 = 0

    def __init__(self, _height, _base, _side_1, _side_2):
        super().__init__()
        self.base = _base
        self.side_1 = _side_1
        self.side_2 = _side_2
        self.height = _height

    def __str__(self):
        return self.name + ":[Area: " + str(self.area()) + ",Perimeter: " + str(self.perimeter()) + "]"

    def area(self):
        return self.base * self.height * 0.5

    def perimeter(self):
        return self.base + self.side_1 + self.side_2


class Circle(GeometricShape):
    name = "Circle"

    radius = 0

    def __init__(self, _radius):
        super().__init__()
        self.radius = _radius

    def __str__(self):
        return self.name + ":[Area: " + str(self.area()) + ",Perimeter: " + str(self.perimeter()) + "]"

    def area(self):
        return pow(self.radius, 2) * 3.14

    def perimeter(self):
        return 2 * self.radius * 3.14


if __name__ == "__main__":

    UserInput = input("Enter the number of the shape:\n1.Rectangle\n2.Triangle\n3.Square\n4.Circle\n")

    if UserInput == '1':
        print("User choice is Rectangle")
        print("input the length of the base")
        base = input()
        print("input the hight")
        hight = input()
        UserInput = Rectangle(int(base), int(hight))
        print(UserInput)

    elif UserInput == '2':
        print("User choice is Triangle")
        print("input the length of the base")
        base = input()
        print("input the hight")
        hight = input()
        print("input side 1")
        side1 = input()
        print("input side 2")
        side2 = input()
        UserInput = Triangle(int(hight), int(base), int(side1), int(side2))
        print(UserInput)

    elif UserInput == '3':
        print("User choice is Square")
        print("input side length")
        side = input()
        UserInput = Square(int(side))
        print(UserInput)

    elif UserInput == "4":
        print("User choice is Circle")
        print("enter radius length")
        radius = input()
        UserInput = Circle(float(radius))
        print(UserInput)

    if __name__ == "__main__":
        unittest.main()


class TestLibrary(unittest.TestCase):

    def test_triangle(self):
        t = Triangle(2, 2, 3, 3)
        self.assertEqual(t.area(), 2)
        self.assertEqual(t.perimeter(), 8)

    def test_rectangle(self):
        r = Rectangle(3, 4)
        self.assertEqual(r.area(), 12)
        self.assertEqual(r.perimeter(), 14)

    def test_square(self):
        s = Square(6)
        self.assertEqual(s.area(), 36)
        self.assertEqual(s.perimeter(), 24)

    def test_circle(self):
        c = Circle(2.5)
        self.assertEqual(c.area(), 19.625)
        self.assertEqual(c.perimeter(), 15.7)

    if __name__ == "__main__":
        unittest.main()