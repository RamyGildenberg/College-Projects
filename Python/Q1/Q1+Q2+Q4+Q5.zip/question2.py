class AMixin(object):
    def mixinExample(self):
        return ("in AMixin.mixinExample " + self.name)


class A(AMixin):
    def __init__(self, name):
        self.name = name


def MixIn(TargetClass, MixInClass):
    if MixInClass not in TargetClass.__bases__:
        TargetClass.__bases__ += (MixInClass,)


if __name__ == "__main__":
    a_instance = A("Question7")
    MixIn(A, AMixin)
    print(a_instance.mixinExample())

''''problem was that all the classes inherited from Object , changing the inheritance of A fixed the issue'''
